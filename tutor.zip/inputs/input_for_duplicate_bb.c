//=============================================================================
// FILE:
//      input_for_duplicate_bb.c
//
// DESCRIPTION:
//      Sample input file for the DuplicateBB pass.
//
// License: MIT
//=============================================================================
int foo(int arg_1) { return 1; }
