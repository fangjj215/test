
#include<stdio.h>

void test2()
{
    
}

void test3()
{
    
}

int test4(int a,int b)
{
    
    return a;
}


int main()
{
    //test2();
    test4(100,99);
    test3();
    return 0;
}
