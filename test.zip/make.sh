# clang -S -emit-llvm   test.c -o test.ll
# clang -emit-llvm -S test.c -o test.ll
# clang -emit-llvm -c test.c -o test.bc

# llvm-as test.ll -o test.bc
# llvm-dis test.bc -o test.ll

# Dump AST : clang –cc1 –ast-dump init.cpp
# ▪ clang-tidy -list-checks
# ▪ clang-tidy -list-checks -checks=*
# ▪ clang-tidy --checks=-*,cppcoreguidelines-init-variables init.cpp --
# ▪ clang-tidy --checks=-*,cppcoreguidelines-init-variables --fix init.cpp –

# clang-tidy --checks=-*,bugprone-sizeof-expression test.c --
# opt -disable-output -passes=helloworld test.ll

# clang -emit-llvm -S test.c -o test.ll
# opt -passes=helloworld test.ll  -o test.bc
# llvm-dis test.bc -o test2.ll

# clang test2.ll -o test

# lang -c -g -emit-llvm -O3 mySource0.c -o mySource0.bc
# clang -c -g -emit-llvm -O3 mySource1.c -o mySource.bc
# llvm-link mySource0.bc mySource1.bc -o main.bc
# opt -load myAnalysis.so -myAnalysis main.bc -o main.analysis.bc
# clang <libraryRelatedFlags> main.analysis.bc -o myExecutable


rm -rf ./build 
mkdir build
cd build 
cmake -G "Ninja" -DCMAKE_TOOLCHAIN_FILE=../clang.cmake -DCMAKE_BUILD_TYPE=Release ..

cmake --build .
./test
