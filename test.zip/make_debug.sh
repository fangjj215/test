

rm -rf ./build 
mkdir build
cd build 
cmake -G "Ninja" -DCMAKE_TOOLCHAIN_FILE=../clang.cmake  ..

cmake --build .
./test

