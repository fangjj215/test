
#gdb -args clang -std=c99 -fpass-plugin=/home/fang/build/llvm/lib/Bye.so test.c
# rm -rf ./test.ll 

# rm -rf ./*.o
/home/fang/下载/llvm-tutor-main/build/lib/libInjectFuncCall.so 
clang  -S -emit-llvm  test.c -o test.ll -fpass-plugin=/home/fang/下载/llvm-tutor-main/build/lib/libInjectFuncCall.so
clang  -emit-llvm -c test.c -o test.bc 
opt -load /home/fang/下载/llvm-tutor-main/build/lib/libInjectFuncCall.so --legacy-inject-func-call test.bc -o instrumented.bin
# clang -S -O1 -emit-llvm   test.c -o test.ll -fpass-plugin=/home/fang/build/llvm/lib/Bye.so
clang -S -O1 -emit-llvm   test.c -o test.ll -fpass-plugin=/home/fang/下载/llvm-tutor-main/build/lib/libInjectFuncCall.so 

clang  -emit-llvm -c test.c -o test.bc
opt -load-pass-plugin /home/fang/下载/llvm-tutor-main/build/lib/libInjectFuncCall.so -passes="inject-func-call" test.bc -o test.bin
lli test.bin
# opt test.ll -o test.bc
#lli test.bc
# #opt -disable-output test.bc -load /home/fang/build/llvm/lib/Bye.so 

# # opt -enable-new-pm=0 -load /home/fang/build/llvm/lib/Bye.so -gvn -licm --debug-pass=Structure < test.bc > /dev/null


clang -fprofile-instr-generate -fcoverage-mapping test.c -o foo
LLVM_PROFILE_FILE="foo.profraw" ./foo

llvm-cov show ./foo -instr-profile=foo.profdata
llvm-profdata merge -sparse foo.profraw -o foo.profdata
llvm-cov report ./foo -instr-profile=foo.profdata

llvm-profdata merge -sparse foo1.profraw foo2.profdata -o foo3.profdata

