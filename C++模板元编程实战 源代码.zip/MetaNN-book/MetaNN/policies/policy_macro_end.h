#undef TypePolicyObj
#undef ValuePolicyObj
#undef TypePolicyTemplate
#undef ValuePolicyTemplate