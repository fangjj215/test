#pragma once

namespace MetaNN
{
template <typename...TCases>
struct OperSeqContainer;

template <typename TOpTag>
struct OperSeq_;
}