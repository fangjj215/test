#pragma once

namespace MetaNN
{
struct NullParameter
{ };
}
