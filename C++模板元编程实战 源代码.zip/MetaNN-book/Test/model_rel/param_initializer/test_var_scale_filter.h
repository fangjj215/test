#pragma once

void test_var_scale_filter();