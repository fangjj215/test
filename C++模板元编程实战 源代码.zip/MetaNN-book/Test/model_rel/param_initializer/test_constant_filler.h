#pragma once

void test_constant_filler();