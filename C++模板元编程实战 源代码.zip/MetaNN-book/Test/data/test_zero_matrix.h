#pragma once

void test_zero_matrix();