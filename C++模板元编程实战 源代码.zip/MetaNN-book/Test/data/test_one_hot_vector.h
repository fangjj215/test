#pragma once

void test_one_hot_vector();