#pragma once

void test_batch_scalar();