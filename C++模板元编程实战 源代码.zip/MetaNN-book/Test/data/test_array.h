#pragma once

void test_array();