#pragma once

void test_scalar();