#pragma once

void test_duplicate();