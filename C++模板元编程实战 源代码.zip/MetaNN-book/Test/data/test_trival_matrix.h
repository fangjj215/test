#pragma once

void test_trival_matrix();