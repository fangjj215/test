#pragma once

void test_policy_operations();