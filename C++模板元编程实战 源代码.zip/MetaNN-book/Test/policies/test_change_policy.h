#pragma once

void test_change_policy();