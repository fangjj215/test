#pragma once

void test_gru_2();
