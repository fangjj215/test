#pragma once

void test_gru();
