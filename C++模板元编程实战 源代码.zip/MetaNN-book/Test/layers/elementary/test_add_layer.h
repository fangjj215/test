#pragma once

void test_add_layer();