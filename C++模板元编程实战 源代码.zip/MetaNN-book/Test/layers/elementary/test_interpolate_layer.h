#pragma once

void test_interpolate_layer();
