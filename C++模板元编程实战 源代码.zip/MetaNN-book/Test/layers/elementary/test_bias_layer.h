#pragma once

void test_bias_layer();