#pragma once

void test_abs_layer();