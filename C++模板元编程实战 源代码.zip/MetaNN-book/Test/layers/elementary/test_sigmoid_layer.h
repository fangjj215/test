#pragma once

void test_sigmoid_layer();