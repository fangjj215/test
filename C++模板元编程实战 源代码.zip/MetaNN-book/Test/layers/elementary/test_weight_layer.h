#pragma once

void test_weight_layer();
