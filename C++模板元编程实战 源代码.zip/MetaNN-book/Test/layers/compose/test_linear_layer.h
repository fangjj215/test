#pragma once

void test_linear_layer();
