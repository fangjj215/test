#pragma once

void test_compose_kernel();