#pragma once

#include <MetaNN/meta_nn.h>

using CheckElement = float;
using CheckDevice = MetaNN::DeviceTags::CPU;