#pragma once

void test_var_type_dict();
