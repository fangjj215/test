#pragma once

void test_interpolate();