#pragma once

void test_softmax_derivative();