#pragma once

void test_element_mul();