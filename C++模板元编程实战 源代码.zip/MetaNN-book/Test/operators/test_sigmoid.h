#pragma once

void test_sigmoid();