#pragma once

void test_divide();