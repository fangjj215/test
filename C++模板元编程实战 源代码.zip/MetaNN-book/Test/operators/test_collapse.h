#pragma once

void test_collapse();