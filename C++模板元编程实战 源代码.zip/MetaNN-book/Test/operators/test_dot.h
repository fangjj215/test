#pragma once

void test_dot();
