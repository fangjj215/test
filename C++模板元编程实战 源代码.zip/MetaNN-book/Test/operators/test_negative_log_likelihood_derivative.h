#pragma once

void test_negative_log_likelihood_derivative();