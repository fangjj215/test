#pragma once

void test_abs();