#pragma once

void test_softmax();