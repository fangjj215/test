#pragma once

void test_add();