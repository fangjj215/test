#pragma once

void test_tanh_derivative();